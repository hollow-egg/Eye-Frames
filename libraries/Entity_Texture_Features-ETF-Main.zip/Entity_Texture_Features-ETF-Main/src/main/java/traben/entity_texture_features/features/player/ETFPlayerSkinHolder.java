package traben.entity_texture_features.features.player;

import org.jetbrains.annotations.Nullable;

public interface ETFPlayerSkinHolder {
    @Nullable ETFPlayerTexture etf$getETFPlayerTexture();
}
