package traben.entity_texture_features.mixin;

public class CancelTarget { }
