package traben.entity_texture_features.utils;

import java.util.Optional;

import net.minecraft.resources.ResourceLocation;

public interface ETFRenderLayerWithTexture {

    Optional<ResourceLocation> etf$getId();
}
