Information accurate as of the 18th of july 2025

# Contributing
## Code
Feel free to make a pull request if you have any changes you would like to make to the code. If you want to ask first you can reach me on my [discord](https://discord.com/invite/rURmwrzUcz)
## Languages
ETF now has a [Crowdin Translate page](https://crowdin.com/project/entity-texture-features) you can contribute to, message me if you need a language added via my [discord](https://discord.com/invite/rURmwrzUcz)

# Building yourself
## Pre processor
ETF uses the ReplayMod preprocessor

