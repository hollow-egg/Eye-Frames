---
name: Suggestion
about: Create a request for an ETF feature or change
title: '[SUGGESTION] "describe suggestion"'
labels: suggestion
assignees: Traben-0

---

Describe your suggestion...

Does another mod also do this?

Does OptiFine do this?
